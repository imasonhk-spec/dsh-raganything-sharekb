# dsh-raganything-kb 0.3.15-sharedkb

分支：8.6 多用户网关线（sharedkb），基线 = 0.3.14-sharedkb。

## 与基线差异（仅三处，其余成员逐字节不变）

| 成员 | 变更 |
| --- | --- |
| `sidecar/server.py` | 回灌 2026-09-19~20 全部 server 侧线上热修（+839/-26 行）：重试解析状态转正链（`_silent_dup` 自愈 / `_find_doc_ids_by_display` 双侧 vroot 归一 / 孪生一起入队）、共享库覆盖保目录树与落点、回收箱（滚动/全部还原/全部删除）、对话产物跨会话账本、产物语义化命名（`semantic_title`）、`/index/reingest` 入队化 |
| `lib/client.js` | 回灌同期前端热修：共享分级目录树、产物栏 session 锚定、共享→个人复制 docId、重试标签、回收箱滚动与整树顶层、语义化命名触发 |
| `package.json` | 版本 0.3.14 -> 0.3.15 |
| `RELEASE-NOTES.md` | 替换为本文件 |

## 为什么出这一版

0.3.14 截止于 2026-09-18；此后 8.6 网关上又落了 **14 项 server 侧 + 8 项 client 侧**热修
（重新解析失败行无法转正、共享库目录树重复嵌套、共享落点与文件夹删除、回收箱三项、
对话产物跨会话隔离、产物语义化命名、共享作用域 @ 命中修复链…），
全部只存在于活副本、从未进入任何发行包。任何 `pnpm install` / 重装 / 回滚
都会把这些修复整体抹掉 —— 本版把它们固化进发行件。

## server.py / client.js 来源（重要）

本版直接取 **8.6 宿主活副本**（`/home/lgsj/.dsh/profiles/web/node_modules/dsh-raganything-kb/`）：

- `server.py` 375559 B md5 `7555955...`（宿主 + 11 份用户副本 **12 份 md5 全一致**）
- `client.js` 410089 B md5 `526ed56d...`

两侧一致意味着 0.3.14 引入的 host-aware 合成（含 `_shared_is_local()` 宿主守卫 + `_route_scope_query`）
已在活副本上收敛为单一权威版本，不再需要分叉合成。

## 顺带说明：为何 0.3.15 未包含「切片离线克隆」代码

2026-09-20 修复的「共享 ZeroClaw @ 范围检索为空」是**数据层**问题（LightRAG 内容哈希去重
导致目标 `file_path` 0 切片），修法是离线把已有切片克隆到精确 `file_path`，
属**运维操作**而非代码变更（工程脚本见 `tools/_zc_clone.py`，未随包发布）。

## 验证

- 载入包内 server.py / client.js，与 8.6 活副本 md5 逐字节一致。
- `py_compile` / `node --check` 通过；无 CRLF 泄漏；无 `.bak` 混入；确定性 md5 复核通过。

## 部署注意

换用本包需同步改 12 份 profile 的依赖（宿主 + 11 用户 home）并重算 pnpm-lock integrity，
否则重装仍会按旧 tgz 还原。宿主重启 `systemctl restart raganything-sidecar`（独立服务）；
用户实例用 `POST :3200N/models/restart` 或整服务重启 `dsh-web`。
