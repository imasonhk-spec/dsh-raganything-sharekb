# dsh-raganything-kb 0.3.14-sharedkb

分支：8.6 多用户网关线（sharedkb），基线 = 0.3.13-sharedkb。

## 与基线差异（仅三处，其余成员逐字节不变）

| 成员 | 变更 |
| --- | --- |
| `sidecar/server.py` | 合入宿主/用户同一份 host-aware 权威版：新增 shared-scope forward 块（含宿主守卫），并补齐 Phase-4 dup 自愈、session 产物账本、重试/回收等全部 server 侧修复 |
| `lib/client.js` | 更新为 8.6 全量热修版（共享分级目录树 / 产物栏 session 锚定 / 共享→个人复制 docId 修复 / 重试标签 / .md 排除 / activeDir 过滤） |
| `lib/client.js.map` | 移除（旧 sourcemap 与新版 client.js 不匹配，保留会误导调试器） |
| `package.json` | 版本 0.3.13 -> 0.3.14 |
| `RELEASE-NOTES.md` | 替换为本文件 |

## 为什么出这一版

0.3.13 只含「@ 共享作用域转发」一项修复；8.6 网关上 2026-09-17~18 又落了 13 个 server 侧与 8 个 client 侧热修，
全部只存在于活副本、从未进入任何发行包。任何 `pnpm install` / 重装 / 回滚都会把上述修复整体抹掉。

## server.py 合成口径（重要）

8.6 活副本的 server.py 是**分叉**的：

- 宿主 GLOBAL（`/home/lgsj/.dsh/profiles/web`，PORT=17321）：含全部 Phase-4/session 修复，但**无** forward 块。
- 用户副本（多用户 home，PORT=3200N）：含 forward 块（无宿主守卫），且与宿主仅在 2 行上有差异。

直接拿任一份装到另一侧都会坏：

- 宿主装用户份 -> 无守卫、转发自环（宿主自己就是共享库本体）。
- 用户装宿主份 -> forward 块丢失，`@` 共享作用域回退为「本地跑、0 命中」。

本版 server.py = 以宿主 GLOBAL 活副本为底，插入 0.3.13 发行包中**带 `_shared_is_local()` 宿主守卫**
的 forward 块，并把唯一的 scoped 调用点改为 `_route_scope_query`。因此同一个文件同时正确服务两侧：

- 宿主 `_shared_is_local()` == True（SHARED_BASE 端口 == PORT）-> 本地检索，不转发。
- 用户 `_shared_is_local()` == False（3200N != 17321）-> 转发宿主 sidecar。

## 验证

- 载入包内 server.py 与 client.js，与 8.6 活副本逐项比对：client.js 与 11 份用户副本 md5 完全一致。
- 4 类修复标记齐备（server: `_ainsert_dup_safe` / `kb-sessions.json` / `_route_scope_query` / `_shared_is_local`；
  client: `buildSharedTree` / `activeSessId` / `executeCopyTo` / `sharedVisibleRows`）。
- `py_compile` / `node --check` 通过；无 CRLF 泄漏；无 `.bak` 混入；确定性 md5 复核通过。

## 部署注意

换用本包需同步改 12 份 profile 的依赖（宿主 + 11 用户 home）并重算 pnpm-lock integrity，
否则重装仍会按旧 tgz 还原。宿主重启 `systemctl restart raganything-sidecar`（独立服务，`restart dsh-web` 不会带上它），
用户实例用 `POST :3200N/models/restart` 或整服务重启 `dsh-web`。
