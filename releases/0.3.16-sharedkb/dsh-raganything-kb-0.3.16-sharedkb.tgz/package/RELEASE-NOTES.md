# dsh-raganything-kb 0.3.16-sharedkb

分支：8.6 多用户网关线（sharedkb），基线 = 0.3.15-sharedkb。

## 与基线差异（仅三处，其余成员逐字节不变）

| 成员 | 变更 |
| --- | --- |
| `sidecar/server.py` | 回灌 2026-09-21 全部 server 侧线上热修（相对基线 +192/-24 行）：①**产物正文抽取** `_artifact_text_of()`（docx/xlsx/pptx 用 python-docx/openpyxl/python-pptx 抽正文，替代旧「office 二进制返回空正文」）；②**跨实例解析** `_global_upload_dir()` + `_original_file_of()` 第三级回退（子账号实例去宿主 uploads 找原始文件）；③**`ingest_file`**：新增 `POST /ingest_file` 端点 + `POST /tasks` 的 `ingest_file` op 分支 + `_copy_file_artifact()`，把外部已生成的 office 文件（dsh-skill-office 产物）直接拷入 `storage/uploads/` 并登记为「仅文件」产物 |
| `package.json` | 版本 0.3.15 -> 0.3.16 |
| `RELEASE-NOTES.md` | 替换为本文件 |

## CRLF 归一（重要，本版特有）

线上宿主活副本的 `server.py`（md5 `a1e8c800…`，391869 B）是 **CRLF 泄漏版**：8465 个换行
全部为 `\r\n`，0 个裸 LF；基线是纯 LF。8 份补丁脚本在 Windows 侧生成/回写时把 `\n`
转成了 `\r\n`，`py_compile` 不会报错，只能靠字节核对发现。

- 打包输入 = 线上活副本按 `CRLF -> LF` 归一后的字节：
  `383404 B`，md5 `cc60b66917834cc7d0c6de1ddfe29b9a`。
- 与基线做 diff 的**真实**改动是 `+192/-24` 行、6 个 hunk（未归一化时会伪装成 8465 行全改）。
- 本版发行件统一为 LF，与仓库与历史发行件口径一致。

## server.py 来源（重要）

本版直接取 **8.6 宿主活副本**（`/home/lgsj/.dsh/profiles/web/node_modules/dsh-raganything-kb/`）：

- `server.py` 原始 `a1e8c800…`（391869 B CRLF）-> 归一后 `cc60b669…`（383404 B LF）
- `lib/client.js` 与基线 0.3.15 逐字节相同（`526ed56d…`，410089 B）—— 本版未动前端

## 为什么要出这一版

0.3.15 截止于 2026-09-20；此后 8.6 网关上又落了 3 项 server 侧热修
（@产物正文抽取支持 office 二进制、跨实例产物解析、`ingest_file` 外部 office 入库），
全部只存在于活副本、从未进入任何发行包。任何 `pnpm install` / 重装 / 回滚
都会把这些修复整体抹掉 —— 本版把它们固化进发行件。

**已观测到的真实回退**：2026-09-22 18:47，账号 `admin` 的 profile 插件目录被按
`file:/home/lgsj/dsh-raganything-kb-0.3.15-sharedkb.tgz` 重新物化，
`sidecar/server.py` 回退为 0.3.15 的 `7555955…`（375559 B）——即本版要消灭的
「热修只活在活副本」风险已实际发生一次。

## 验证

- 包内 `server.py` LF 归一后与 8.6 宿主活副本逐字节一致；`client.js` 与 0.3.15 一致。
- 修复标记齐备：server 12 项（含 `_artifact_text_of` / `_global_upload_dir` /
  `_copy_file_artifact` / `ingest_file`）、client 6 项（沿用 0.3.15）。
- `py_compile` / `node --check` 通过；无 CRLF 泄漏；无 `.bak` 混入；确定性 md5 复核通过。

## 部署注意

换用本包需同步改 12 份 profile 的依赖（宿主 + 11 用户 home）并重算 pnpm-lock integrity，
否则重装仍会按旧 tgz 还原（0.3.15 -> 0.3.16 未换指符时，`admin` 这类实例会继续回退）。
宿主重启 `systemctl restart raganything-sidecar`（独立服务）；用户实例用
`POST :3200N/models/restart` 或整服务重启 `dsh-web`。
